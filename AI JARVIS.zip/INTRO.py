import time
from tkinter import *
from PIL import Image, ImageTk, ImageSequence
from pygame import mixer

# Initialize music
mixer.init()

# Create main window
root = Tk()
root.geometry("1000x500")
root.title("JARVIS Intro")

# Play intro function
def play_gif():
    try:
        root.lift()
        root.attributes("-topmost", True)

        print("Enter password to open Jarvis :-Sai")
        print("WELCOME SIR ! PLZ SPEAK [WAKE UP] TO LOAD ME UP")

        # Play music
        mixer.music.load("Startup.mp3")
        mixer.music.play()

        # Load and play GIF
        gif = Image.open("jarvis.gif")
        lbl = Label(root)
        lbl.place(x=0, y=0)

        for frame in ImageSequence.Iterator(gif):
            frame = frame.resize((1000, 500))
            img = ImageTk.PhotoImage(frame)
            lbl.config(image=img)
            root.update()
            time.sleep(0.05)

        # Close window after playback
        root.after(500, root.destroy)

    except Exception as e:
        print(f"[ERROR] {e}")

# Start playback after window loads
root.after(100, play_gif)
root.mainloop()
