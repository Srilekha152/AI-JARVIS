import speech_recognition as sr
import pyttsx3
import wikipedia
import threading
import tkinter as tk

# Initialize the TTS engine (Text-to-Speech)
engine = pyttsx3.init()

# Lock to ensure only one TTS operation runs at a time
engine_lock = threading.Lock()

# Function for setting the TTS voice (optional, you can tweak voices here)
def set_voice():
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)  # Choose voice[0] or voice[1] (male/female)

# Function to speak out the answer
def speak(text):
    with engine_lock:  # Ensure that TTS is only called once at a time
        engine.say(text)
        engine.runAndWait()

# Function to perform the Wikipedia search and speak the result
def search_wikipedia(question):
    try:
        # Search Wikipedia
        result = wikipedia.summary(question, sentences=2, lang='en')
        speak(result)
    except wikipedia.exception.DisambiguationError:
        speak("There are multiple results for your query. Could you be more specific?")
    except wikipedia.exception.HTTPTimeoutError:
        speak("I couldn't fetch data from Wikipedia. Please check your connection.")
    except wikipedia.exception.RedirectError:
        speak("The query led to a redirect. Please try another query.")
    except wikipedia.exception.HTTPError as e:
        speak(f"HTTP error: {e}")
    except Exception as e:
        speak(f"An error occurred: {e}")

# Function to capture voice input and process the query
def listen_for_question():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for a question...")
        audio = recognizer.listen(source)

    try:
        # Recognize speech using Google Web Speech API
        question = recognizer.recognize_google(audio)
        print(f"Question: {question}")

        if 'stop' in question.lower():  # Check if the keyword 'stop' is in the query
            speak("Goodbye! Ending the conversation.")
            print("Goodbye! Ending the conversation.")
            return  # Exit the function and stop further processing

        # Perform Wikipedia search
        search_wikipedia(question)

    except sr.UnknownValueError:
        speak("Sorry, I couldn't understand your speech.")
    except sr.RequestError:
        speak("Sorry, I am unable to connect to the speech service.")
    except Exception as e:
        speak(f"An error occurred: {e}")

# Function to start the conversation loop in a separate thread
def start_conversation():
    while True:
        listen_for_question()  # Keep listening until 'stop' is said

# Function to start the GUI
def start_gui():
    # Initialize Tkinter window for GUI display
    root = tk.Tk()
    root.title("AI Jarvis - Wikipedia Query")
    root.geometry("500x300")

    # Label for displaying the answer
    answer_label = tk.Label(root, text="Ask me something...", font=("Arial", 14), wraplength=400)
    answer_label.pack(pady=50)

    # Start the Tkinter event loop
    root.mainloop()

# Start the conversation loop in a background thread
conversation_thread = threading.Thread(target=start_conversation, daemon=True)
conversation_thread.start()

# Start the GUI in the main thread
start_gui()
