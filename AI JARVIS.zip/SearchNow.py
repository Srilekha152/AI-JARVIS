import pyttsx3
import pywhatkit
import speech_recognition
import wikipedia

# Initialize Text-to-Speech Engine
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("voice", voices[0].id)
engine.setProperty("rate", 170)

def speak(audio):
    print(f"JARVIS: {audio}")  # Debug
    engine.say(audio)
    engine.runAndWait()

def takeCommand():
    r = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        r.energy_threshold = 300
        audio = r.listen(source, 0, 4)
    try:
        print("Understanding...")
        query = r.recognize_google(audio, language='en-in')
        print(f"You said: {query}\n")
    except Exception as e:
        print("Error understanding:", e)
        return "None"
    return query.lower()

def searchGoogle(query):
    speak("Searching Google...")
    pywhatkit.search(query)

def searchYoutube(query):
    speak("Opening YouTube...")
    pywhatkit.playonyoutube(query)

def searchWikipedia(query):
    speak("Searching Wikipedia...")
    try:
        result = wikipedia.summary(query, sentences=2)
        print("Wikipedia Result:", result)
        speak("According to Wikipedia...")
        speak(result)
    except Exception as e:
        speak("Sorry, I couldn't find anything on Wikipedia.")
        print("Wikipedia error:", e)


# === MAIN ===
query = takeCommand()

if "google" in query:
    query = query.replace("google", "")
    searchGoogle(query)

elif "youtube" in query:
    query = query.replace("youtube", "")
    searchYoutube(query)

else:
    searchWikipedia(query)
