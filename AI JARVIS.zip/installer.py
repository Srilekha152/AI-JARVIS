import pip
from PIL.Image import module


pip.main(['install','speechrecognition'])